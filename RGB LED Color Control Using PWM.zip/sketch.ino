const int RED = 9;
const int GREEN = 10;
const int BLUE = 11;

void setup()
{
  pinMode(RED, OUTPUT);
  pinMode(GREEN, OUTPUT);
  pinMode(BLUE, OUTPUT);
}

void setColor(int r, int g, int b)
{
  analogWrite(RED, r);
  analogWrite(GREEN, g);
  analogWrite(BLUE, b);
}

void loop()
{
  setColor(255, 0, 0);       // Red
  delay(1000);

  setColor(0, 255, 0);       // Green
  delay(1000);

  setColor(0, 0, 255);       // Blue
  delay(1000);

  setColor(255, 255, 0);     // Yellow
  delay(1000);

  setColor(0, 255, 255);     // Cyan
  delay(1000);

  setColor(255, 0, 255);     // Magenta
  delay(1000);

  setColor(255, 255, 255);   // White
  delay(1000);

  setColor(0, 0, 0);         // OFF
  delay(1000);
}
